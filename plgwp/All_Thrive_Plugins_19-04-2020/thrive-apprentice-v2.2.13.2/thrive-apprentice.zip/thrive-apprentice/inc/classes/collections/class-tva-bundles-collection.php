<?php
/**
 * Created by PhpStorm.
 * User: User
 * Date: 5/6/2019
 * Time: 12:43
 */

class TVA_Bundles_Collection extends TVA_Products_Collection {
	/**
	 * @var string
	 */
	protected $model = 'TVA_Bundle_Model';
}