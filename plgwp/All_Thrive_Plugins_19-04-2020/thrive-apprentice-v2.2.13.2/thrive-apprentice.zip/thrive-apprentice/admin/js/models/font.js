/**
 * Web safe Fonts model
 */

var base_model = require( './base' );

module.exports = base_model.extend( {} );
