var base = require( './base' );

module.exports = base.extend( {

	model: require( '../models/variation' )

} );
