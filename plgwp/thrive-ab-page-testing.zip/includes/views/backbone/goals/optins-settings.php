<?php
/**
 * Thrive Themes - https://thrivethemes.com
 *
 * @package thrive-ab-page-testing
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Silence is golden
}
?>
<p>
	<?php echo __( 'Measure the number of visitors who subscribe to your website. Please make sure you add at least one Lead Generation form on each variation for the conversions to be counted.', 'thrive-ab-page-testing' ); ?>
</p>
