<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Silence is golden
}
?>

<span class="click" data-fn="view_conversion_goal_details">
	<?php tcb_icon( 'visit_gp' ) ?><?php echo __( 'Page Visit Conversion Goal', 'thrive-ab-page-testing' ); ?>
</span>
