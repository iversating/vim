<?php
/**
 * Created by PhpStorm.
 * User: Ovidiu
 * Date: 2/1/2018
 * Time: 3:47 PM
 */
?>
<tr>
	<td style="text-align: center;" colspan="7"><?php echo __( 'You have no running test with that name', 'thrive-ab-page-testing' ); ?></td>
</tr>
