<div class="tve_lp_header tve_empty_dropzone">
</div>

<div class="tve_lp_content tve_editor_main_content tve_empty_dropzone tve_content_width">
	<div class="thrv_wrapper thrv_page_section" data-tve-style="1" style="margin-bottom: 190px;">
		<div class="out" style="background-color: #d4343e;">
			<div class="in lightSec">
				<div class="cck tve_clearfix">
					<h1 class="tve_p_center" style="color: #fff; font-size: 56px; font-weight: 100; margin: 100px 0 0 0;">Thank you <span class="bold_text">for Signing Up!</span></h1>
					<h3 class="tve_p_center" style="color: #fff; font-size: 28px; margin: 30px 0 50px 0;">Click the <span class="bold_text">Download Button</span> to get our Product</h3>
					<div class="thrv_wrapper thrv_contentbox_shortcode tve_copydownload_cb" data-tve-style="5">
						<div class="tve_cb tve_cb5 tve_green" style="margin-top: 210px; margin-bottom: -210px;">
							<div class="tve_cb_cnt">
								<div style="width: 308px; margin-top: -220px; margin-bottom: 30px;" class="thrv_wrapper tve_image_caption aligncenter">
                                    <span class="tve_image_frame">
                                        <img class="tve_image"
                                             src="<?php echo TVE_LANDING_PAGE_TEMPLATE . '/css/images/copy_download_cd.png' ?>"
                                             style="width: 308px"/>
                                    </span>
								</div>
								<div class="thrv_wrapper thrv_button_shortcode tve_centerBtn" data-tve-style="1">
									<div class="tve_btn tve_btn7 tve_green tve_bigBtn tve_nb" style="margin-bottom: 30px;">
										<a href="" class="tve_btnLink">
                                            <span class="tve_left tve_btn_im">
                                                <i></i>
                                            </span>
											<span class="tve_btn_txt">DOWNLOAD</span>
										</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="thrv_wrapper thrv_contentbox_shortcode" data-tve-style="6">
		<div class="tve_cb tve_cb6 tve_green" style="margin-top: 50px;">
			<div class="tve_cb_cnt">
				<p style="font-size: 29px; color: #000000;">
					If you enjoy our Free Product, you can get the platinum package now with only
                    <span class="bold_text">
                        <font color="#2e5c2e">59$</font>
                    </span>
					<a href="http://thrivethemes.com" target="_blank">
						<font color="#333">
							&gt;&gt; Check out our premium offer
						</font>
					</a>
				</p>
			</div>
		</div>
	</div>
</div>


<div class="tve_lp_footer tve_empty_dropzone">
	<div class="thrv_wrapper thrv_page_section" data-tve-style="1">
		<div class="out" style="background-color: #333333">
			<div class="in">
				<div class="cck tve_clearfix">
					<p class="tve_p_center" style="margin: 2px 0; padding: 0; font-size: 16px">
						&copy; {tcb_current_year} by ACME Inc. - <a href="#"><span class="underline_text">Disclaimer</span></a>
					</p>
				</div>
			</div>
		</div>
	</div>
</div>