<div class="tve_lp_header tve_empty_dropzone tve_drop_constraint" data-forbid=".thrv_page_section,.sc_page_section">
	<div style="width: 268px;" class="thrv_wrapper tve_image_caption aligncenter">
        <span class="tve_image_frame">
            <img class="tve_image" src="<?php echo TVE_LANDING_PAGE_TEMPLATE . '/css/images/blank-logo.png' ?>" style="width: 268px"/>
        </span>
	</div>
</div>

<div class="tve_lp_content tve_editor_main_content tve_empty_dropzone thrv_wrapper tve_no_drag">
	<h1>This is your first H1 heading</h1>
</div>

<div class="tve_lp_footer tve_empty_dropzone tve_drop_constraint" data-forbid=".thrv_page_section,.sc_page_section">
	<p class="tve_p_center" style="color: #909090;"><a href="">Privacy Policy</a> - <a href="">Disclaimer</a> - <a href="">Contact Us</a></p>
</div>