<h2 style="color: #fff;font-size: 38px; margin-bottom: 40px; margin-top: 0;" class="tve_p_center rft">
	Sign Up for the Webinar:
</h2>
<div class="thrv_wrapper thrv_lead_generation tve_clearfix tve_teal tve_fullwidthBtn tve_3 thrv_lead_generation_vertical"
     data-inputs-count="3" data-tve-style="1" style="margin-bottom: 0;">
	<div class="thrv_lead_generation_code" style="display: none;"></div>
	<div class="thrv_lead_generation_container tve_clearfix">
		<div class="tve_lead_generated_inputs_container tve_clearfix">
			<div class="tve_lead_fields_overlay"></div>
			<div class=" tve_lg_input_container tve_lg_3 tve_lg_input">
				<input type="text" data-placeholder="Your Name" placeholder="First Name" value=""
				       name="first_name"/>
			</div>
			<div class=" tve_lg_input_container tve_lg_3 tve_lg_input">
				<input type="text" data-placeholder="Email address" placeholder="Last Name" value=""
				       name="last_name"/>
			</div>
			<div class="tve_lg_input_container tve_submit_container tve_lg_3 tve_lg_submit">
				<button type="Submit">GET ACCESS</button>
			</div>
		</div>
	</div>
</div>
