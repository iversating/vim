<div class="control-grid wrap">
	<label for="v-v-url"><?php echo __( 'URL', 'thrive-cb' ) ?></label>
	<input type="text" data-setting="url" class="v-url fill" id="v-v-url">
</div>
<div class="vooplayer-url-validate inline-message"></div>