<div class="thrv_wrapper thrv_toggle_shortcode" data-hover-color="#1abc9c" data-text-hover-color="#fff">
	<div class="tve_faq">
		<div class="tve_faqI">
			<div class="tve_faqB">
				<svg class="tve_toggle" id="tcb-icon-caret-right-solid" viewBox="0 0 192 512" width="100%" height="100%">
					<path d="M0 384.662V127.338c0-17.818 21.543-26.741 34.142-14.142l128.662 128.662c7.81 7.81 7.81 20.474 0 28.284L34.142 398.804C21.543 411.404 0 402.48 0 384.662z"></path>
				</svg>
				<h4 class="tve_editable"><?php echo __( 'Content Toggle Headline', 'thrive-cb' ); ?></h4>
			</div>
			<div class="tve_faqC" style="display: none;"></div>
		</div>
	</div>
</div>
