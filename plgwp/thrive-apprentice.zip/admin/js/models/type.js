var base_model = require( './base' );

module.exports = base_model.extend( {
	defaults: {
		type: '',
		checked: true
	}
} );
