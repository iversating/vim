( function ( $ ) {

	var baseView = require( '../base' );

	var pageStateView = require( '../page-state' );

	/**
	 * View to render register options
	 */
	var registerOptions = pageStateView.extend( {
		template: TVE_Dash.tpl( 'sendowl/checkout/checkout' ),
		className: 'tva-tab tva-register-options',
		events: {},
		initialize: function ( args ) {
			pageStateView.prototype.initialize.apply( this, arguments );

			this.model = ThriveApp.globals.soSettings.get( 'checkout_page' );
		},
		render: function () {
			this.$el.html( this.template( {model: this.model} ) );

			new pageStateView( {
				el: this.$( '.tva-registration-page-container' ),
				model: this.model,
				deleteMsg: ThriveApp.t.deleteRegPage,
				headlineMsg: ThriveApp.t.setChPage
			} ).render();

			return this;
		}
	} );

	/**
	 * View to render redirect options for thankyou page
	 */
	var redirectOptionsView = pageStateView.extend( {
		template: TVE_Dash.tpl( 'sendowl/redirect' ),
		events: {},
		initialize: function () {
			ThriveApp.globals.soSettings.get( 'welcome_message' ).on( 'tva_tinymce_blur', function () {
				this.save( ThriveApp.globals.soSettings.get( 'welcome_message' ) );
			}, this )
		},
		render: function () {

			var url = ThriveApp.globals.soSettings.get( 'preview_msg_url' ) + '?show_welcome_msg=true';

			this.$el.html( this.template( {
				model: this.model,
				preview: url
			} ) );

			new pageStateView( {
				el: this.$( '.tva-thankyou-page-multiple' ),
				model: ThriveApp.globals.soSettings.get( 'thankyou_multiple_page' )
			} ).render();

			this.renderMCE();
			return this;
		},
		renderMCE: function () {
			var self = this;
			setTimeout( function () {
				var editors = [ 'tva-thankyou-message' ];
				ThriveApp.util.clearMCEEditor( editors );
				ThriveApp.util.editorInit( 'tva-thankyou-message', ThriveApp.globals.soSettings.get( 'welcome_message' ), 'message' );
				TVE_Dash.materialize( self.$el );
			}, 0 );
		}
	} );

	/**
	 * View to render thankyou page options
	 */
	var thankyouOptions = pageStateView.extend( {
		className: 'tva-tab tva-thankyou-options tva-hide',
		template: TVE_Dash.tpl( 'sendowl/checkout/thankyou' ),
		events: {
			'click .tva-thankyou-type': 'changeType'
		},
		initialize: function () {
			pageStateView.prototype.initialize.apply( this, arguments );

			this.model = ThriveApp.globals.soSettings.get( 'thankyou_page_type' );
		},
		render: function () {
			this.$el.html( this.template( {model: this.model} ) );

			var view = '',
				soSettings = ThriveApp.globals.soSettings;

			switch ( this.model.get( 'type' ) ) {

				case 'static':
					view = pageStateView;

					this.$( '.tva-thankyou-wrapper' ).html( '<div class="tva-static-thankyou-page"></div>' );
					break;

				case 'redirect':
					view = redirectOptionsView;

					break;

				default:
					break;
			}

			var $el = this.model.get( 'type' ) === 'static' ? this.$( '.tva-static-thankyou-page' ) : this.$( '.tva-thankyou-wrapper' );

			new view( {
				el: $el,
				model: soSettings.get( 'thankyou_page' )
			} ).render();

			if ( false === soSettings.get( 'tcb_plugin_active' ) ) {
				this.$( '.tva-page-option' ).addClass( 'tcb-inactive' );
			}

			if ( false === soSettings.get( 'tutorial_completed' ) && 1 === soSettings.get( 'show_thankyou_tutorial' ) ) {
				this.$( '.tva-notice' ).removeClass( 'tva-hide' );
			}

			return this;
		},
		changeType: function ( e ) {
			this.model.set( {type: e.currentTarget.dataset.type} );

			this.save();
		}
	} );

	module.exports = baseView.extend( {
		className: 'tvd-container',
		template: TVE_Dash.tpl( 'sendowl/checkout' ),
		events: {
			'click .tva-tab-item': 'setActiveTab'
		},
		activeTab: 'register',
		tabs: {
			register: registerOptions,
			thankyou: thankyouOptions,
		},
		render: function () {
			this.$el.html( this.template( {model: this.model} ) );

			this.renderActiveTab();

			ThriveApp.util.rebindWistiaFancyBoxes();

			return this;
		},
		renderActiveTab: function () {
			var tabView = this.tabs[ this.activeTab ];
			var tabName = this.getTabViewName();

			if ( ! tabView || ! tabView instanceof Backbone.View ) {
				return;
			}

			if ( this[ tabName ] instanceof Backbone.View ) {
				this[ tabName ].remove();
			}

			this[ tabName ] = new tabView( {} );

			this.$( '.tva-checkout-tabs' ).append( this[ tabName ].render().$el );
			this.$( '[data-tab="' + this.activeTab + '"]' ).addClass( 'tva-active-tab' );
		},
		getTabViewName: function () {
			return this.activeTab + 'View';
		},
		setActiveTab: function ( e ) {
			var tab = e.currentTarget.dataset.tab;

			if ( this.activeTab === tab ) {
				return;
			}

			this.activeTab = tab;

			if ( ! ( this[ this.getTabViewName() ] instanceof Backbone.View ) ) {
				this.renderActiveTab();
			}

			this.$( '.tva-tab-item' ).removeClass( 'tva-active-tab' );
			this.$( e.currentTarget ).addClass( 'tva-active-tab' );
			this.$( '.tva-tab' ).addClass( 'tva-hide' );
			this.$( '.tva-' + tab + '-options' ).removeClass( 'tva-hide' );

			ThriveApp.util.rebindWistiaFancyBoxes();
		}
	} );

} )( jQuery );
