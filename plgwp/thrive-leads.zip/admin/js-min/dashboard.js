/*! Thrive Leads - The ultimate Lead Capture solution for wordpress - 2020-03-18
* https://thrivethemes.com 
* Copyright (c) 2020 * Thrive Themes */

var ThriveLeads=ThriveLeads||{};jQuery(document).ready(function(a){Backbone.history.fragment||ThriveLeads.router.navigate("#dashboard",{trigger:!0})});