<div class="thrv-greedy-ribbon tve_no_drag tve_no_icons tve_element_hover thrv_wrapper tve_gr_seven_set tve_black" style="background-image: url('<?php echo TVE_LEADS_URL . 'editor-templates/_form_css/images/gr_seven_set_bg.jpg' ?>');background-size: cover; background-position: center center;">
	<div class="tve-greedy-ribbon-content tve_editor_main_content">
		<div class="thrv_wrapper thrv_contentbox_shortcode" data-tve-style="5">
			<div class="tve_cb tve_cb5 tve_white">
				<div class="tve_cb_cnt">
					<div class="thrv_wrapper thrv_content_container_shortcode">
						<div class="tve_clear"></div>
						<div class="tve_center tve_content_inner" style="width: 910px;min-width:50px; min-height: 2em;">
							<h2 class="tve_p_center rft" style="color: #666666; font-size: 65px;margin-top: 60px;margin-bottom: 0;">
								<font color="#0065bb">Get More FREE TIME</font>
								by Minimizing Procrastination
							</h2>
						</div>
						<div class="tve_clear"></div>
					</div>
				</div>
			</div>
		</div>
		<div class="thrv_wrapper thrv_content_container_shortcode">
			<div class="tve_clear"></div>
			<div class="tve_center tve_content_inner" style="width: 910px;min-width:50px; min-height: 2em;margin-top: 120px;">
				<div class="thrv_wrapper thrv_contentbox_shortcode" data-tve-style="6">
					<div class="tve_cb tve_cb6 tve_white">
						<div class="tve_cb_cnt">
							<div style="margin-top: -100px;width: 140px;" class="thrv_wrapper tve_image_caption aligncenter gr-seven-set-image">
                                 <span class="tve_image_frame">
                                    <img class="tve_image"
                                         src="<?php echo TVE_LEADS_URL . 'editor-templates/_form_css/images/47_set_image.png' ?>"
                                         style="width: 140px"/>
                                </span>
							</div>
							<div class="thrv_wrapper thrv_content_container_shortcode">
								<div class="tve_clear"></div>
								<div class="tve_center tve_content_inner" style="width: 795px;min-width:50px; min-height: 2em;margin-top: 20px;">
									<p class="tve_p_center" style="color: #666666; font-size: 22px;margin-top: 0;margin-bottom: 40px;">
										Tell them about your products major advantages and use the photo above to illustrate your product, or use as author photo.
									</p>
								</div>
								<div class="tve_clear"></div>
							</div>
							<div class="thrv_wrapper thrv_content_container_shortcode">
								<div class="tve_clear"></div>
								<div class="tve_center tve_content_inner" style="width: 450px;min-width:50px; min-height: 2em;">
									<div class="thrv_wrapper thrv_button_shortcode tve_fullwidthBtn" data-tve-style="1">
										<div class="tve_btn tve_btn3 tve_nb tve_orange tve_normalBtn">
											<a class="tve_btnLink tve_evt_manager_listen tve_et_click" href=""
											   data-tcb-events="|open_state_2|">
                                                <span class="tve_left tve_btn_im">
                                                    <i></i>
                                                    <span class="tve_btn_divider"></span>
                                                </span>
												<span class="tve_btn_txt">I Want to Have More Free Time</span>
											</a>
										</div>
									</div>
								</div>
								<div class="tve_clear"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="tve_clear"></div>
		</div>
		<div class="thrv_wrapper thrv_icon aligncenter gr-close-button tve_no_drag">
            <span data-tve-icon="gr-seven-set-close"
                  class="tve_sc_icon gr-seven-set-close tve_white tve_evt_manager_listen tve_et_click"
                  style="font-size: 90px;" data-tcb-events="|close_form|"></span>
		</div>
	</div>
</div>


