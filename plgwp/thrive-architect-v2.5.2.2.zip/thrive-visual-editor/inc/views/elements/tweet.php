<div class="thrv_wrapper thrv_tw_qs tve_clearfix" data-url="https://twitter.com/intent/tweet" data-via="" data-use_custom_url="">
	<div class="thrv_tw_qs_container">
		<div class="thrv_tw_quote">
			<p><?php echo __( 'Insert your tweetable quote/phrase here', 'thrive-cb' ) ?></p>
		</div>
		<div class="thrv_tw_qs_button tve_p_right">
			<span>
				<i></i>
				<span class="thrv_tw_qs_button_text "><?php echo __( 'Click to Tweet', 'thrive-cb' ) ?></span>
			</span>
		</div>
	</div>
</div>
