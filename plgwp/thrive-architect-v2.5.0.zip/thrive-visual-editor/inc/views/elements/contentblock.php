<?php
/**
 * Created by PhpStorm.
 * User: Ovidiu
 * Date: 2/18/2019
 * Time: 10:18 AM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Silence is golden!
}
?>

<div class="thrv_wrapper thrv-content-block tcb-elem-placeholder">
	<span class="tcb-inline-placeholder-action with-icon">
		<?php tcb_icon( 'add', false, 'editor' ); ?>
		<?php echo __( 'Add Content Block', 'thrive-cb' ); ?>
	</span>
</div>
