<div class="thrv_wrapper thrv_columns tve_clearfix" style="margin-top: 0;margin-bottom: 0;">
	<div class="tve_colm tve_oth">
		<div class="thrv_wrapper thrv_contentbox_shortcode" data-tve-style="6">
			<div class="tve_cb tve_cb6 tve_blue" style="margin-top: -2px; margin-left: -18px; margin-bottom: -20px;padding-top: 30px;">
				<div class="tve_cb_cnt">
					<div style="width: 238px;margin-top: 20px;" class="thrv_wrapper tve_image_caption aligncenter">
                        <span class="tve_image_frame">
                            <img class="tve_image"
                                 src="<?php echo TVE_LANDING_PAGE_TEMPLATE . '/css/images/edition-lightbox-product.png' ?>"
                                 style="width: 238px;"/>
                        </span>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="tve_colm tve_tth tve_lst">
		<div class="thrv_wrapper thrv_contentbox_shortcode" data-tve-style="6">
			<div class="tve_cb tve_cb6 tve_white" style="padding-left: 40px;padding-right: 40px;padding-top: 30px;">
				<div class="tve_cb_cnt">
					<h4 style="color:#333745;font-size: 40px;margin-top: 0;margin-bottom: 33px;">Sign Up and Get the <span class="bold_text">Free Sample</span> sent to your inbox</h4>
					<div class="thrv_wrapper thrv_lead_generation tve_clearfix thrv_lead_generation_vertical tve_blue" style="margin-bottom: 28px;"
					     data-tve-style="1">
						<div class="thrv_lead_generation_code" style="display: none;"></div>
						<div class="thrv_lead_generation_container tve_clearfix">
							<div class="tve_lead_generated_inputs_container tve_clearfix">
								<div class="tve_lead_fields_overlay"></div>
								<div class=" tve_lg_input_container ">
									<input type="text" data-placeholder="" value="" name="name" placeholder="Name"/>
								</div>
								<div class="tve_lg_input_container">
									<input type="text" data-placeholder="" value="" name="email" placeholder="Email"/>
								</div>
								<div class="tve_lg_input_container tve_submit_container">
									<button type="Submit">DOWNLOAD THE FREE REPORT</button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>