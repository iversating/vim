<div class="thrv_wrapper thrv_content_container_shortcode">
	<div class="tve_clear"></div>
	<div class="tve_center tve_content_inner" style="width: 420px;min-width:50px; min-height: 2em;margin-bottom: 0px;margin-top: 40px;">
		<h1 style="color: #fff; font-size: 38px;margin-bottom: 0;" class="tve_p_center">Steps to Make Your Website More Profitable</h1>
	</div>
	<div class="tve_clear"></div>
</div>
<div class="thrv_wrapper thrv_lead_generation tve_clearfix tve_teal tve_centerBtn" data-tve-style="1" style="margin-bottom:18px; max-width: 600px;">
	<div class="thrv_lead_generation_code" style="display: none;"></div>
	<div class="thrv_lead_generation_container tve_clearfix">
		<div class="tve_lead_generated_inputs_container tve_clearfix">
			<div class="tve_lead_fields_overlay" style="width: 100%; height: 100%;"></div>
			<div class=" tve_lg_input_container ">
				<input type="text" data-placeholder="First Name" placeholder="First Name" value="" name="first_name"/>
			</div>
			<div class="tve_lg_input_container">
				<input type="text" data-placeholder="Last Name" placeholder="Last Name" value="" name="last_name"/>
			</div>
			<div class="tve_lg_input_container">
				<input type="text" data-placeholder="Email" placeholder="Email" value="" name="email"/>
			</div>
			<div class="tve_lg_input_container tve_submit_container">
				<button type="Submit">Get Acces to Your Complete Free Guide</button>
			</div>
		</div>
	</div>
</div>
