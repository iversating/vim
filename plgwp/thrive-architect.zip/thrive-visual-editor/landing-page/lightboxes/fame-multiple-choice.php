<div class="thrv_wrapper thrv_columns tve_clearfix">
	<div class="tve_colm tve_oth">
		<div style="width: 258px;" class="thrv_wrapper tve_image_caption aligncenter img_style_lifted_style2">
            <span class="tve_image_frame">
                <img class="tve_image"
                     src="<?php echo TVE_LANDING_PAGE_TEMPLATE . '/css/images/fame_shane.png' ?>"
                     style="width: 258px"/>
            </span>
		</div>
	</div>
	<div class="tve_colm tve_tth tve_lst">
		<h2 class="tve_p_center">“3-Step system” for finding out where
			your business is leaking money</h2>
		<h1 class="tve_p_center">(and how to fix it).</h1>
		<div class="thrv_wrapper" style="margin-bottom: 0;margin-top: 0;">
			<hr class="tve_sep tve_sep1"/>
		</div>
		<div class="thrv_wrapper thrv_lead_generation tve_clearfix tve_purple" data-tve-style="1" style="margin-bottom:18px; margin-top: 0;">
			<div class="thrv_lead_generation_code" style="display: none;"></div>
			<div class="thrv_lead_generation_container tve_clearfix">
				<div class="tve_lead_generated_inputs_container tve_clearfix">
					<div class="tve_lead_fields_overlay" style="width: 100%; height: 100%;"></div>
					<div class=" tve_lg_input_container ">
						<input type="text" data-placeholder="Name here..." placeholder="Name here..." value="" name="first_name"/>
					</div>
					<div class="tve_lg_input_container">
						<input type="text" data-placeholder="Email here..." placeholder="Email here..." value="" name="last_name"/>
					</div>
					<div class="tve_lg_input_container tve_submit_container">
						<button type="Submit">SUBSCRIBE NOW!</button>
					</div>
				</div>
			</div>
			<p class="tve_p_center fame_lock" style="color: #333333;font-size:16px;margin-bottom:0">
				Your Privacy is protected.
			</p>
		</div>
	</div>
</div>



