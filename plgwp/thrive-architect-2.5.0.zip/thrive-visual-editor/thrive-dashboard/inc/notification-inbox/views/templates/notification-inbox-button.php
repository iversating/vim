<?php
/**
 * Thrive Themes - https://thrivethemes.com
 *
 * @package thrive-dashboard
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Silence is golden!
}
?>

<li class="ni-inbox-counter">
	<a id="tvd-notifications-btn" href="javascript:void(0)" class="tvd-ni-notifications"></a>
	<span class="ni-counter-holder" style="display: none;"></span>
</li>
